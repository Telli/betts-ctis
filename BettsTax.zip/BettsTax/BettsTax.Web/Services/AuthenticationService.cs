using System.Collections.Concurrent;
using System.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using BettsTax.Web.Models;

namespace BettsTax.Web.Services
{
    /// <summary>
    /// Authentication service implementation using JWT
    /// </summary>
    public class AuthenticationService : IAuthenticationService
    {
        private readonly JwtSettings _jwtSettings;
        private readonly ILogger<AuthenticationService> _logger;

        private static readonly ConcurrentDictionary<string, RefreshTokenRecord> _refreshTokens = new();

        private static string HashPassword(string password) => BCrypt.Net.BCrypt.HashPassword(password);

        // In-memory user store for demo purposes
        // In production, replace with database access (EF Core, Dapper, etc.)
        private static readonly List<User> _demoUsers = new()
        {
            new User
            {
                UserId = "staff-001",
                Email = "staff@bettsfirm.com",
                PasswordHash = HashPassword("password"),
                Role = "Staff",
                ClientId = null,
                ClientName = null,
                IsActive = true,
                CreatedAt = DateTime.UtcNow.AddMonths(-6)
            },
            new User
            {
                UserId = "client-001",
                Email = "client@example.com",
                PasswordHash = HashPassword("password"),
                Role = "Client",
                ClientId = 1,
                ClientName = "ABC Corporation",
                IsActive = true,
                CreatedAt = DateTime.UtcNow.AddMonths(-3)
            },
            new User
            {
                UserId = "client-002",
                Email = "john@xyztrad.com",
                PasswordHash = HashPassword("password"),
                Role = "Client",
                ClientId = 2,
                ClientName = "XYZ Trading",
                IsActive = true,
                CreatedAt = DateTime.UtcNow.AddMonths(-2)
            },
            new User
            {
                UserId = "admin-001",
                Email = "admin@bettsfirm.com",
                PasswordHash = HashPassword("password"),
                Role = "Admin",
                ClientId = null,
                ClientName = null,
                IsActive = true,
                CreatedAt = DateTime.UtcNow.AddYears(-1)
            }
        };

        public AuthenticationService(
            IOptions<JwtSettings> jwtSettings,
            ILogger<AuthenticationService> logger)
        {
            _jwtSettings = jwtSettings.Value;
            _logger = logger;
        }

        public async Task<LoginResponse> AuthenticateAsync(LoginRequest request)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(request.Email) ||
                    string.IsNullOrWhiteSpace(request.Password))
                {
                    return new LoginResponse
                    {
                        Success = false,
                        Message = "Email and password are required"
                    };
                }

                // Find user by email
                var user = _demoUsers.FirstOrDefault(u =>
                    u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase));

                if (user == null || !user.IsActive)
                {
                    _logger.LogWarning("Failed login attempt for email: {Email}", request.Email);
                    return new LoginResponse
                    {
                        Success = false,
                        Message = "Invalid email or password"
                    };
                }

                // Verify password using bcrypt to avoid timing attacks and plaintext comparison
                var isPasswordValid = false;
                try
                {
                    isPasswordValid = BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Password verification failed for user: {UserId}", user.UserId);
                }

                if (!isPasswordValid)
                {
                    _logger.LogWarning("Failed password verification for user: {UserId}", user.UserId);
                    return new LoginResponse
                    {
                        Success = false,
                        Message = "Invalid email or password"
                    };
                }

                // Update last login
                user.LastLoginAt = DateTime.UtcNow;

                // Generate tokens
                var token = GenerateJwtToken(user);
                var refreshToken = GenerateRefreshToken();
                var expiresAt = DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationMinutes);
                var refreshTokenExpiresAt = DateTime.UtcNow.AddDays(GetRefreshTokenLifetimeDays());

                SaveRefreshToken(user, refreshToken, refreshTokenExpiresAt);

                _logger.LogInformation("Successful login for user: {UserId} with role: {Role}",
                    user.UserId, user.Role);

                return new LoginResponse
                {
                    Success = true,
                    Message = "Login successful",
                    Token = token,
                    RefreshToken = refreshToken,
                    ExpiresAt = expiresAt,
                    RefreshTokenExpiresAt = refreshTokenExpiresAt,
                    User = MapToUserInfo(user)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during authentication for email: {Email}", request.Email);
                return new LoginResponse
                {
                    Success = false,
                    Message = "An error occurred during authentication"
                };
            }
        }

        public async Task<bool> ValidateTokenAsync(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(_jwtSettings.Secret);

                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = _jwtSettings.Issuer,
                    ValidateAudience = true,
                    ValidAudience = _jwtSettings.Audience,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Token validation failed");
                return await Task.FromResult(false);
            }
        }

        public async Task<UserInfo?> GetUserFromTokenAsync(string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadJwtToken(token);

                var userId = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
                var email = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
                var role = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;
                var clientId = jwtToken.Claims.FirstOrDefault(c => c.Type == "ClientId")?.Value;
                var clientName = jwtToken.Claims.FirstOrDefault(c => c.Type == "ClientName")?.Value;

                if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(email))
                {
                    return null;
                }

                return await Task.FromResult(new UserInfo
                {
                    UserId = userId,
                    Email = email ?? string.Empty,
                    Role = role ?? string.Empty,
                    ClientId = int.TryParse(clientId, out var cId) ? cId : null,
                    ClientName = clientName
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting user from token");
                return null;
            }
        }

        public async Task<LoginResponse> RefreshTokenAsync(string refreshToken)
        {
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                return await Task.FromResult(new LoginResponse
                {
                    Success = false,
                    Message = "Refresh token is required"
                });
            }

            try
            {
                PurgeExpiredTokens();

                var tokenHash = HashRefreshToken(refreshToken);
                if (!_refreshTokens.TryGetValue(tokenHash, out var tokenRecord))
                {
                    _logger.LogWarning("Attempt to use unknown refresh token");
                    return await Task.FromResult(new LoginResponse
                    {
                        Success = false,
                        Message = "Invalid refresh token"
                    });
                }

                if (tokenRecord.ExpiresAt <= DateTime.UtcNow)
                {
                    _refreshTokens.TryRemove(tokenHash, out _);
                    _logger.LogInformation("Expired refresh token rejected for user {UserId}", tokenRecord.UserId);
                    return await Task.FromResult(new LoginResponse
                    {
                        Success = false,
                        Message = "Refresh token has expired"
                    });
                }

                var user = _demoUsers.FirstOrDefault(u =>
                    u.UserId == tokenRecord.UserId && u.IsActive);

                if (user == null)
                {
                    _refreshTokens.TryRemove(tokenHash, out _);
                    _logger.LogWarning("Refresh token attempted for inactive or missing user {UserId}", tokenRecord.UserId);
                    return await Task.FromResult(new LoginResponse
                    {
                        Success = false,
                        Message = "User session is no longer valid"
                    });
                }

                var newAccessToken = GenerateJwtToken(user);
                var newRefreshToken = GenerateRefreshToken();
                var expiresAt = DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationMinutes);
                var refreshTokenExpiresAt = DateTime.UtcNow.AddDays(GetRefreshTokenLifetimeDays());

                SaveRefreshToken(user, newRefreshToken, refreshTokenExpiresAt);

                _logger.LogInformation("Refresh token rotated for user {UserId}", user.UserId);

                return await Task.FromResult(new LoginResponse
                {
                    Success = true,
                    Message = "Token refreshed successfully",
                    Token = newAccessToken,
                    RefreshToken = newRefreshToken,
                    ExpiresAt = expiresAt,
                    RefreshTokenExpiresAt = refreshTokenExpiresAt,
                    User = MapToUserInfo(user)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error refreshing token");
                return await Task.FromResult(new LoginResponse
                {
                    Success = false,
                    Message = "Unable to refresh session"
                });
            }
        }

        public Task RevokeRefreshTokenAsync(string refreshToken)
        {
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                return Task.CompletedTask;
            }

            var tokenHash = HashRefreshToken(refreshToken);
            _refreshTokens.TryRemove(tokenHash, out _);
            _logger.LogInformation("Refresh token revoked");
            return Task.CompletedTask;
        }

        public async Task<RegisterResponse> RegisterAsync(RegisterRequest request)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(request.Email) ||
                    string.IsNullOrWhiteSpace(request.Password))
                {
                    return new RegisterResponse
                    {
                        Success = false,
                        Message = "Email and password are required"
                    };
                }

                // Check if user already exists
                if (_demoUsers.Any(u => u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase)))
                {
                    return new RegisterResponse
                    {
                        Success = false,
                        Message = "A user with this email already exists"
                    };
                }

                // Create new user (default to Client role for registration)
                var newUser = new User
                {
                    UserId = $"user-{Guid.NewGuid().ToString("N")[..8]}",
                    Email = request.Email,
                    PasswordHash = HashPassword(request.Password),
                    Role = "Client", // Default role for new registrations
                    ClientId = null, // Will be set later if needed
                    ClientName = request.CompanyName,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                };

                _demoUsers.Add(newUser);

                _logger.LogInformation("New user registered: {UserId} with email: {Email}", newUser.UserId, newUser.Email);

                return await Task.FromResult(new RegisterResponse
                {
                    Success = true,
                    Message = "Registration successful",
                    User = MapToUserInfo(newUser)
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during registration for email: {Email}", request.Email);
                return new RegisterResponse
                {
                    Success = false,
                    Message = "An error occurred during registration"
                };
            }
        }

        private int GetRefreshTokenLifetimeDays()
        {
            return Math.Max(1, _jwtSettings.RefreshTokenExpirationDays <= 0
                ? 7
                : _jwtSettings.RefreshTokenExpirationDays);
        }

        private void SaveRefreshToken(User user, string refreshToken, DateTime expiresAt)
        {
            PurgeExpiredTokens();

            foreach (var entry in _refreshTokens.Where(kvp => kvp.Value.UserId == user.UserId).ToList())
            {
                _refreshTokens.TryRemove(entry.Key, out _);
            }

            var tokenHash = HashRefreshToken(refreshToken);
            _refreshTokens[tokenHash] = new RefreshTokenRecord(user.UserId, expiresAt, DateTime.UtcNow);
        }

        private void PurgeExpiredTokens()
        {
            foreach (var entry in _refreshTokens.Where(kvp => kvp.Value.ExpiresAt <= DateTime.UtcNow).ToList())
            {
                _refreshTokens.TryRemove(entry.Key, out _);
            }
        }

        private static string HashRefreshToken(string refreshToken)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(refreshToken));
            return Convert.ToBase64String(bytes);
        }

        private static UserInfo MapToUserInfo(User user) => new()
        {
            UserId = user.UserId,
            Email = user.Email,
            Role = user.Role,
            ClientId = user.ClientId,
            ClientName = user.ClientName
        };

        private sealed record RefreshTokenRecord(string UserId, DateTime ExpiresAt, DateTime CreatedAt);

        private string GenerateJwtToken(User user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_jwtSettings.Secret);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(JwtRegisteredClaimNames.Sub, user.UserId),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            // Add client-specific claims if user is a client
            if (user.ClientId.HasValue)
            {
                claims.Add(new Claim("ClientId", user.ClientId.Value.ToString()));
                if (!string.IsNullOrEmpty(user.ClientName))
                {
                    claims.Add(new Claim("ClientName", user.ClientName));
                }
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(_jwtSettings.ExpirationMinutes),
                Issuer = _jwtSettings.Issuer,
                Audience = _jwtSettings.Audience,
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
    }
}
